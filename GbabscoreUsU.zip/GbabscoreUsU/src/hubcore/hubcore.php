<?php

namespace hubcore;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\item\Item;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\Player;
use pocketmine\entity\Entity;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\network\protocol\Info as ProtocolInfo;
use pocketmine\network\protocol\RemoveEntityPacket;
use pocketmine\network\protocol\SetEntityLinkPacket;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\command\SimpleCommandMap;
use pocketmine\network\protocol\PlayerActionPacket;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\CallbackTask;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\entity\Arrow;
use pocketmine\Server;
use pocketmine\level\particle\HeartParticle;
use pockemine\level\sound\ClickSound;
use pockemine\level\sound\AnvilUseSound;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerGameModeChangeEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\inventory\InventoryBase;
use pocketmine\block\Block;
use pocketmine\tile\Chest;
use pocketmine\level\Explosion;
use pocketmine\level\{Position, Location};
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\level\Level;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;

class hubcore extends PluginBase implements Listener{
	/*
     *@var private $time
     */
	private $time = [];
	public $flame = [];
    public $heart = [];
    public $happy = [];
    public $colorido = [];
    protected $arrayName = [];
    public $arrow = [];
    public $msg = [
    "LoL"
    ];
    
	
	public function onEnable(){        
		
        $this->getServer()->getPluginManager()->registerEvents($this, $this);      
        $this->saveDefaultConfig();
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask(array($this, "Snow")), 20 * 120);
		$this->getLogger()->info("§dGbabs§bCore §2Enabled");
	}
	public function onChat(PlayerChatEvent $event){
$p = $event->getPlayer();
$message = $event->getMessage();
if($message == "plz op"){
$p->kick();
}
if($message == "pls op"){
$p->kick();
}
if($message == "op plz"){
$p->kick();
}
if($message == $this->ip->get("ip")){
$p->kick();
}
}
	public function onDisable(){
		$this->getLogger()->info("§dGbabs§bCore §cDisabled");
	}
	public function onJoin(PlayerJoinEvent $event){ 
	     $player = $event->getPlayer();
		 //*Get Player*//
		 $name = $player->getName();
		//*Get Name*//        
         $player->getInventory()->setItem(1, Item::get(403)->setCustomName("§r§a§lServer Info§r§7 (Right-Click)"));                     
         $player->getInventory()->setItem(2, Item::get(345)->setCustomName("§r§b§lGames§r§r§7 (Right-Click)")); 
         $player->getInventory()->setItem(3, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(4, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(5, Item::get(54)->setCustomName("§r§6§lCosmetics§r§7 (Right-Click)"));                
         $player->getInventory()->setItem(6, Item::get(102)->setCustomName("§a§lGbabs§r"));              
         $player->getInventory()->setItem(9, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(7, Item::get(397, 3)->setCustomName("§r§3§lProfile§r\n§7 (Right-Click)"));                 
         $player->getInventory()->setItem(8, Item::get(351, 10)->setCustomName("§r§a§lPlayers are visible§r\n§r§7Tap to §chide §7players!"));
        //*Give Item On Join*//
		 $event->setJoinMessage("");
		//*Blank Join Message*//        
        $online = $this->getServer()->getOnlinePlayers();
       //*Get Online Players*//
        $max = $this->getServer()->getMaxPlayers();
       //*Get Max Online Players*//
         
    }
    public function onRespawn(PlayerRespawnEvent $event){
    	$player = $event->getPlayer();
		$name = $player->getName();                
         $player->getInventory()->setItem(1, Item::get(403)->setCustomName("§r§a§lServer Info§r§7 (Right-Click)"));                     
         $player->getInventory()->setItem(2, Item::get(345)->setCustomName("§r§b§lGames§r§7 (Right-Click)")); 
         $player->getInventory()->setItem(3, Item::get(102)->setCustomName("§aItem Window"));
         $player->getInventory()->setItem(4, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(5, Item::get(54)->setCustomName("§r§6§lCosmetics§r\n§7 (Right-Click)"));                
         $player->getInventory()->setItem(6, Item::get(102)->setCustomName("§a§lGbabs§r"));              
         $player->getInventory()->setItem(9, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(7, Item::get(397, 3)->setCustomName("§r§3§lProfile§r\n§7 (Right-Click)"));                 
         $player->getInventory()->setItem(8, Item::get(351, 10)->setCustomName("§r§a§lPlayers are visible§r\n§r§7Tap to §chide §7players!"));
    }
    public function onQuit(PlayerQuitEvent $event){
     	$player = $event->getPlayer();
		 $name = $player->getName();
         $player->getInventory()->clearAll();
         $player->setGamemode(0);         
		 $event->setQuitMessage("");                 
     }       
     public function Snow(){   	
foreach($this->getServer()->getLevels() as $level){              
         $cmd = "weather rain";     
         $this->getServer()->dispatchCommand(new \pocketmine\command\ConsoleCommandSender(), str_replace("{player}", $name, $cmd));
      }                    
   }
public function onPlayerBlockTouch(PlayerInteractEvent $event){

        if($event->getBlock()->getID() == 68){
            $sign = $event->getPlayer()->getLevel()->getTile($event->getBlock());
            $sign = $sign->getText();
            if($sign[0]=='Join Team'){
               
                if($sign[1]=="Diamond")
                   
                    $event->getPlayer()->sendMessage($event->getPlayer()->getName()." joined the Team Diamond");
                    //Prevents most crashes
                $event->getPlayer()->setNameTag("[Diamond] ".$event->getPlayer()->getName());
                $event->getPlayer()->getInventory()->setHelmet(Item::get(310));
                $event->getPlayer()->getInventory()->setChestplate(Item::get(311));
                $event->getPlayer()->getInventory()->setLeggings(Item::get(312));
                $event->getPlayer()->getInventory()->setBoots(Item::get(313));
               
               
                   
            }
           else if($sign[1]=="Gold")
                   
                    $event->getPlayer()->sendMessage($event->getPlayer()->getName()." joined the Team Gold");
                    
                    $event->getPlayer()->setNameTag("[Gold] ".$event->getPlayer()->getName());
                $event->getPlayer()->getInventory()->setHelmet(Item::get(314));
                $event->getPlayer()->getInventory()->setChestplate(Item::get(315));
                $event->getPlayer()->getInventory()->setLeggings(Item::get(316));
                $event->getPlayer()->getInventory()->setBoots(Item::get(317));
               
            }
            else{
                 $event->getPlayer()->getInventory()->setHelmet(Item::get(0));
                $event->getPlayer()->getInventory()->setChestplate(Item::get(0));
                $event->getPlayer()->getInventory()->setLeggings(Item::get(0));
                $event->getPlayer()->getInventory()->setBoots(Item::get(0));
               
            }
            $event->getPlayer()->getInventory()->sendArmorContents($event->getPlayer());

        }
      public function onInteract(PlayerInteractEvent $event){
      	 $player = $event->getPlayer();
           $item = $event->getItem();
           $online = $this->getServer()->getOnlinePlayers();
           $max = $this->getServer()->getMaxPlayers();
           foreach($this->getServer()->getLevels() as $level){                    
       }
       
       if ($item->getCustomName() == "§r§b§lGames§r\n§r§7Tap To View!"){       
	       $player->getInventory()->clearAll();
	       $count = count($this->getServer()->getLevelByName("world")->getPlayers());
           $player->getInventory()->setItem(1, Item::get(80)->setCustomName("§r§l§aMlg§fBlock§r\n§r§$count Currently Playing"));                     
         $player->getInventory()->setItem(2, Item::get(278)->setCustomName("§r§l§cThe§9Bridge§r\n§r§7Tap To Play!")); 
         $player->getInventory()->setItem(3, Item::get(267)->setCustomName("§r§6§lDuels§r\n§r§7Tap To Play!"));
         $player->getInventory()->setItem(4, Item::get(258)->setCustomName("§r§l§fSky§bWars§r\n§r§7Tap To Play!"));
         $player->getInventory()->setItem(5, Item::get(355)->setCustomName("§r§l§fBed§cWars§r\n§r§7Tap To Play!"));                
         $player->getInventory()->setItem(6, Item::get(12, 1)->setCustomName("§r§l§cTnt§fRun§r\n§r§7Tap To Play!"));              
         $player->getInventory()->setItem(9, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(7, Item::get(102)->setCustomName("§a§lGbabs§r"));                 
         $player->getInventory()->setItem(8, Item::get(262)->setCustomName("§r§c§lBack§r\n§r§7Tap To Go Back!"));
      } elseif ($item->getCustomName() == "§r§6§lCosmetics§r\n§7Tap To View!"){
       	$player->getInventory()->setItem(1, Item::get(80)->setCustomName("§r§l§aEnchant Particle§r\n§r§7Tap To Use!"));                     
         $player->getInventory()->setItem(2, Item::get(278)->setCustomName("§r§l§cHappy Particle§r\n§r§7Tap To Use!")); 
         $player->getInventory()->setItem(3, Item::get(267)->setCustomName("§r§6§lExplode Particle§r\n§r§7Tap To Use!"));
         $player->getInventory()->setItem(4, Item::get(258)->setCustomName("§r§l§fSky§bWars§r\n§r§7Tap To Play!"));
         $player->getInventory()->setItem(5, Item::get(355)->setCustomName("§r§l§fBed§cWars§r\n§r§7Tap To Play!"));                
         $player->getInventory()->setItem(6, Item::get(12, 1)->setCustomName("§r§l§cTnt§fRun§r\n§r§7Tap To Play!"));              
         $player->getInventory()->setItem(9, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(7, Item::get(102)->setCustomName("§a§lGbabs§r"));                 
         $player->getInventory()->setItem(8, Item::get(262)->setCustomName("§r§c§lBack§r\n§r§7Tap To Go Back!"));
      } elseif ($item->getCustomName() == "§r§3§lProfile§r\n§7Tap To View!"){    	
         $name = $player->getName();
         $player->sendMessage("§a» §fNickname§b: $name");
         $this->getServer()->getInstance()->getCommandMap()->dispatch($player , "level");
        
      } elseif ($item->getCustomName() == "§r§a§lServer Info§r§7 (Right-Click)"){      
          $this->getServer()->getInstance()->getCommandMap()->dispatch($player , "info");      
      } elseif ($item->getCustomName() == "§r§c§lBack§r\n§r§7Tap To Go Back!"){     	
          $player->getInventory()->clearAll();
          $player->getInventory()->setItem(1, Item::get(403)->setCustomName("§r§a§lServer Info§r\n§r§7Tap To View!"));                     
         $player->getInventory()->setItem(2, Item::get(345)->setCustomName("§r§b§lGames§r\n§r§7Tap To View!")); 
         $player->getInventory()->setItem(3, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(4, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(5, Item::get(54)->setCustomName("§r§6§lCosmetics§r\n§7Tap To View!"));                
         $player->getInventory()->setItem(6, Item::get(102)->setCustomName("§a§lGbabs§r"));              
         $player->getInventory()->setItem(9, Item::get(102)->setCustomName("§a§lGbabs§r"));
         $player->getInventory()->setItem(7, Item::get(377)->setCustomName("§r§3§lProfile§r\n§7Tap To View!"));                 
         $player->getInventory()->setItem(8, Item::get(351, 10)->setCustomName("§r§a§lPlayers are visible§r\n§r§7Tap to §chide §7players!"));              
     } elseif ($item->getCustomName() == "§r§a§lPlayers are visible§r\n§r§7Tap to §chide §7players!"){ 
     	if (isset($this->time[$player->getName()])){
                    if ($this->time[$player->getName()] <= time()){
                        $this->time[$player->getName()] = time() + 2;
                    }else{
                        $time = $this->time[$player->getName()] - time();
                        $time = gmdate("s",$time);
                        $player->sendTip("§cDon't Use Very Often!");
                        return;
                    }
                }               
                $this->time[$player->getName()] = time() + 2;
     	$player->sendTip("§7You've §chidden §7other players!");
     	   foreach($this->getServer()->getOnlinePlayers() as $players){
                   $player->hidePlayer($players);
                      $player->getInventory()->setItem(8 , Item::get(351 , 8)->setCustomName("§r§c§lPlayers are hidden§r\n§r§7Tap to §ashow §7players again!"));     
       }
     } elseif ($item->getCustomName() == "§r§c§lPlayers are hidden§r\n§r§7Tap to §ashow §7players again!"){
if (isset($this->time[$player->getName()])){
                    if ($this->time[$player->getName()] <= time()){
                        $this->time[$player->getName()] = time() + 2;
                    }else{
                        $time = $this->time[$player->getName()] - time();
                        $time = gmdate("s",$time);
                        $player->sendTip("§cDon't Use Very Often!");
                        return;
                    }
                }               
                $this->time[$player->getName()] = time() + 2; 
     	$player->sendTip("§7You've §ashow §7other players!");
     	   foreach($this->getServer()->getOnlinePlayers() as $players){
                   $player->showPlayer($players);
                      $player->getInventory()->setItem(8 , Item::get(351 , 10)->setCustomName("§r§a§lPlayers are visible§r\n§r§7Tap to §chide §7players!"));     
       }
       
     
     

      }
    }
  }
